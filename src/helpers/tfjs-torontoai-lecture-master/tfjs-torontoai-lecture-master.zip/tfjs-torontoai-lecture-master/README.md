# README #

Contains material for the May 2nd 2019 Toronto-AI presentation on Tensorflow JS. 
